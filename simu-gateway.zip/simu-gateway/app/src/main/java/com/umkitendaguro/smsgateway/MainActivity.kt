package com.umkitendaguro.smsgateway

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.widget.*

/** Weka mara MOJA: Project ID, API key, email+password ya akaunti ya Gateway, na namba ya SIM hii. */
class MainActivity : Activity() {
    private lateinit var storage: SecureStorage

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        storage = SecureStorage(this)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        fun field(hintText: String, initial: String, pwd: Boolean = false) = EditText(this).apply {
            setHint(hintText); setText(initial); if (pwd) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val project = field("Firebase Project ID", storage.projectId)
        val apiKey = field("Firebase apiKey (Web API key)", storage.apiKey)
        val email = field("Email ya akaunti ya Gateway", storage.email)
        val password = field("Password ya akaunti ya Gateway", "", true)
        val number = field("Namba ya SIM ya simu hii (mf. 0700000001)", storage.gatewayNumber)
        val btn = Button(this).apply { text = "Hifadhi na Anzisha Gateway" }
        val info = TextView(this).apply { text = "Namba lazima ilingane na ile Developer aliyoiweka kwenye Developer Console > SMS." }
        listOf(info, project, apiKey, email, password, number, btn).forEach { layout.addView(it) }
        setContentView(ScrollView(this).apply { addView(layout) })

        btn.setOnClickListener {
            storage.projectId = project.text.toString().trim(); storage.apiKey = apiKey.text.toString().trim()
            storage.email = email.text.toString().trim(); storage.gatewayNumber = number.text.toString().trim()
            if (password.text.isNotBlank()) storage.password = password.text.toString()
            if (!storage.isConfigured()) { Toast.makeText(this, "Jaza sehemu zote", Toast.LENGTH_LONG).show(); return@setOnClickListener }
            askPermissionsThenStart()
        }
    }

    private fun askPermissionsThenStart() {
        val need = mutableListOf(Manifest.permission.SEND_SMS)
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 100) else start()
    }
    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        if (results.isNotEmpty() && results.all { it == PackageManager.PERMISSION_GRANTED }) start()
        else Toast.makeText(this, "Ruhusa ya kutuma SMS inahitajika", Toast.LENGTH_LONG).show()
    }
    private fun start() {
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName))
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        val svc = Intent(this, GatewayService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc) else startService(svc)
        Toast.makeText(this, "Gateway imeanza", Toast.LENGTH_SHORT).show()
    }
}
