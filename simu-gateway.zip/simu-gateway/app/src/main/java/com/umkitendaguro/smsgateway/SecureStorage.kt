package com.umkitendaguro.smsgateway

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Siri zote (password ya Gateway n.k.) zinahifadhiwa zimesimbwa ndani ya simu hii tu. */
class SecureStorage(context: Context) {
    private val prefs = EncryptedSharedPreferences.create(
        context, "gateway_secure_prefs",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
    private fun get(k: String) = prefs.getString(k, "") ?: ""
    private fun set(k: String, v: String) = prefs.edit().putString(k, v).apply()

    var projectId: String get() = get("projectId"); set(v) = set("projectId", v)
    var apiKey: String get() = get("apiKey"); set(v) = set("apiKey", v)
    var email: String get() = get("email"); set(v) = set("email", v)
    var password: String get() = get("password"); set(v) = set("password", v)
    var gatewayNumber: String get() = get("gatewayNumber"); set(v) = set("gatewayNumber", v)

    fun isConfigured() = projectId.isNotBlank() && apiKey.isNotBlank() && email.isNotBlank() &&
            password.isNotBlank() && gatewayNumber.isNotBlank()

    /** Namba kama 0712345678 -> +255712345678 (lazima ilingane na ile ya Developer Console). */
    fun normalizedNumber(): String {
        val s = gatewayNumber.replace(Regex("[\\s\\-().]"), "")
        return when {
            s.startsWith("+") -> s
            s.startsWith("255") && s.length == 12 -> "+$s"
            s.startsWith("0") && s.length == 10 -> "+255" + s.substring(1)
            else -> s
        }
    }
    fun gatewayDocId() = normalizedNumber().replace(Regex("\\D"), "")
}
