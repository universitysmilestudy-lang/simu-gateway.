package com.umkitendaguro.smsgateway

import okhttp3.FormBody
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.util.concurrent.TimeUnit

data class Sms(
    val id: String, val name: String, val updateTime: String, val to: String, val body: String,
    val attempts: Int, val maxAttempts: Int, val retryAfter: String?, val claimedAt: String?
)

/** Inazungumza na Firestore moja kwa moja (REST) kwa akaunti ya "Gateway" ya Firebase. Hakuna server ya kati. */
class FirebaseRest(private val s: SecureStorage) {
    private val http = OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(25, TimeUnit.SECONDS).build()
    private val json = "application/json".toMediaType()
    private var idToken = ""
    private var refreshToken = ""
    private var expiresAt = 0L

    private fun base() = "https://firestore.googleapis.com/v1/projects/${s.projectId}/databases/(default)/documents"
    private fun str(v: String) = JSONObject().put("stringValue", v)
    private fun int(v: Int) = JSONObject().put("integerValue", v.toString())

    private fun signIn(): Boolean {
        val body = JSONObject().put("email", s.email).put("password", s.password).put("returnSecureToken", true)
        val req = Request.Builder().url("https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${s.apiKey}")
            .post(body.toString().toRequestBody(json)).build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) return false
            val j = JSONObject(r.body!!.string())
            idToken = j.getString("idToken"); refreshToken = j.getString("refreshToken")
            expiresAt = System.currentTimeMillis() + j.getString("expiresIn").toLong() * 1000
            return true
        }
    }
    private fun refresh(): Boolean {
        val form = FormBody.Builder().add("grant_type", "refresh_token").add("refresh_token", refreshToken).build()
        val req = Request.Builder().url("https://securetoken.googleapis.com/v1/token?key=${s.apiKey}").post(form).build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) return false
            val j = JSONObject(r.body!!.string())
            idToken = j.getString("id_token"); refreshToken = j.getString("refresh_token")
            expiresAt = System.currentTimeMillis() + j.getString("expires_in").toLong() * 1000
            return true
        }
    }
    fun ensureAuth(): Boolean {
        if (idToken.isNotEmpty() && System.currentTimeMillis() < expiresAt - 60_000) return true
        if (refreshToken.isNotEmpty() && refresh()) return true
        return signIn()
    }
    private fun req(url: String) = Request.Builder().url(url).header("Authorization", "Bearer $idToken")

    /** Je, Developer ameiwasha Gateway hii? (gateways/{namba}.active == true) */
    fun isGatewayActive(): Boolean {
        http.newCall(req("${base()}/gateways/${s.gatewayDocId()}").get().build()).execute().use { r ->
            if (!r.isSuccessful) return false
            val f = JSONObject(r.body!!.string()).optJSONObject("fields") ?: return false
            return f.optJSONObject("active")?.optBoolean("booleanValue", false) ?: false
        }
    }

    /** Inaonyesha Developer kwamba simu iko hai (Last Seen + ONLINE). */
    fun heartbeat() {
        val fields = JSONObject().put("lastSeenAt", str(Instant.now().toString())).put("connection", str("ONLINE"))
        val url = "${base()}/gateways/${s.gatewayDocId()}?updateMask.fieldPaths=lastSeenAt&updateMask.fieldPaths=connection"
        http.newCall(req(url).patch(JSONObject().put("fields", fields).toString().toRequestBody(json)).build()).execute().close()
    }

    private fun query(status: String): List<Sms> {
        fun eq(field: String, v: String) = JSONObject().put("fieldFilter", JSONObject()
            .put("field", JSONObject().put("fieldPath", field)).put("op", "EQUAL").put("value", str(v)))
        val q = JSONObject().put("structuredQuery", JSONObject()
            .put("from", JSONArray().put(JSONObject().put("collectionId", "smsQueue")))
            .put("where", JSONObject().put("compositeFilter", JSONObject().put("op", "AND")
                .put("filters", JSONArray().put(eq("status", status)).put(eq("gatewayNumber", s.normalizedNumber())))))
            .put("limit", 20))
        val rq = req("${base()}:runQuery").post(q.toString().toRequestBody(json)).build()
        http.newCall(rq).execute().use { r ->
            if (!r.isSuccessful) return emptyList()
            val arr = JSONArray(r.body!!.string())
            val out = ArrayList<Sms>()
            for (i in 0 until arr.length()) {
                val d = arr.getJSONObject(i).optJSONObject("document") ?: continue
                val f = d.getJSONObject("fields"); val name = d.getString("name")
                fun s2(k: String) = f.optJSONObject(k)?.optString("stringValue")?.takeIf { it.isNotEmpty() }
                fun i2(k: String, def: Int) = f.optJSONObject(k)?.optString("integerValue")?.toIntOrNull() ?: def
                out.add(Sms(name.substringAfterLast('/'), name, d.getString("updateTime"), s2("to") ?: continue, s2("body") ?: continue,
                    i2("attempts", 0), i2("maxAttempts", 3), s2("retryAfter"), s2("claimedAt")))
            }
            return out
        }
    }
    fun pending(): List<Sms> {
        val now = Instant.now()
        return query("PENDING").filter { it.retryAfter == null || !Instant.parse(it.retryAfter).isAfter(now) }
    }
    /** SMS zilizokwama "SENDING" kwa zaidi ya dakika 5 (simu ilizimika katikati) zinarudishwa PENDING. */
    fun recoverStuck() {
        val limit = Instant.now().minusSeconds(300)
        query("SENDING").filter { it.claimedAt != null && Instant.parse(it.claimedAt).isBefore(limit) }.forEach {
            patch(it, mapOf("status" to str("PENDING")), listOf("status"), checkTime = false)
            log(it.id, "RECOVERED", "ilikwama SENDING - imerudishwa PENDING")
        }
    }

    private fun patch(m: Sms, fields: Map<String, JSONObject>, mask: List<String>, checkTime: Boolean = true): Boolean {
        val qs = mask.joinToString("&") { "updateMask.fieldPaths=$it" } + if (checkTime) "&currentDocument.updateTime=${m.updateTime}" else ""
        val body = JSONObject().put("fields", JSONObject().also { o -> fields.forEach { (k, v) -> o.put(k, v) } })
        http.newCall(req("https://firestore.googleapis.com/v1/${m.name}?$qs").patch(body.toString().toRequestBody(json)).build()).execute().use { return it.isSuccessful }
    }
    fun log(id: String, event: String, detail: String) {
        val fields = JSONObject().put("event", str(event)).put("detail", str(detail)).put("at", str(Instant.now().toString()))
        http.newCall(req("${base()}/smsQueue/$id/logs").post(JSONObject().put("fields", fields).toString().toRequestBody(json)).build()).execute().close()
    }

    /** Inadai SMS: PENDING -> SENDING (inashindwa ikiwa mtu mwingine ameshaibadilisha = hakuna kutuma mara mbili). */
    fun claim(m: Sms): Boolean {
        val ok = patch(m, mapOf("status" to str("SENDING"), "attempts" to int(m.attempts + 1), "claimedAt" to str(Instant.now().toString())),
            listOf("status", "attempts", "claimedAt"))
        if (ok) log(m.id, "CLAIMED", "jaribio ${m.attempts + 1}/${m.maxAttempts}")
        return ok
    }
    fun markSent(m: Sms) {
        patch(m, mapOf("status" to str("SENT"), "sentAt" to str(Instant.now().toString())), listOf("status", "sentAt"), checkTime = false)
        log(m.id, "SENT", "imetumwa kwa SIM ya Gateway")
    }
    /** Imeshindwa: rudisha PENDING (jaribio jingine baada ya dakika) au FAILED ikiwa majaribio yamekwisha. */
    fun markFailed(m: Sms, error: String) {
        val attempts = m.attempts + 1
        val retry = attempts < m.maxAttempts
        val fields = mutableMapOf("status" to str(if (retry) "PENDING" else "FAILED"), "lastError" to str(error.take(200)))
        val mask = mutableListOf("status", "lastError")
        if (retry) { fields["retryAfter"] = str(Instant.now().plusSeconds(60L * attempts).toString()); mask.add("retryAfter") }
        patch(m, fields, mask, checkTime = false)
        log(m.id, if (retry) "RETRY_QUEUED" else "FAILED", error)
    }
}
