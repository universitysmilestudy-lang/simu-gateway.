package com.umkitendaguro.smsgateway

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.telephony.SmsManager
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Foreground service: inaendelea nyuma, inafuatilia mtandao, inajiunganisha tena yenyewe, inatuma SMS kwa SIM ya kawaida. */
class GatewayService : Service() {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private lateinit var storage: SecureStorage
    private lateinit var api: FirebaseRest
    private var job: Job? = null
    private var wake: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        storage = SecureStorage(this); api = FirebaseRest(storage)
        startForeground(1, notification("Inaanza..."))
        wake = (getSystemService(Context.POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "umgateway:loop").apply { acquire() }
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { startLoop() }   // mtandao ukirudi -> endelea mara moja
        })
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int { startLoop(); return START_STICKY }

    private fun startLoop() {
        job?.cancel()
        job = scope.launch {
            var backoff = 5_000L
            while (isActive) {
                try {
                    if (!online()) { update("Hakuna mtandao - inasubiri..."); delay(5_000); continue }
                    if (!api.ensureAuth()) { update("Imeshindwa kuingia Firebase (kagua email/password ya Gateway)"); delay(backoff); backoff = (backoff * 2).coerceAtMost(120_000); continue }
                    backoff = 5_000L
                    api.heartbeat()
                    if (!api.isGatewayActive()) { update("Gateway imezimwa na Developer"); delay(15_000); continue }
                    api.recoverStuck()
                    val list = api.pending()
                    update("Mtandaoni · SMS zinazosubiri: ${list.size}")
                    for (m in list) {
                        if (!api.claim(m)) continue
                        val (ok, err) = sendAndWait(m.to, m.body)
                        if (ok) api.markSent(m) else api.markFailed(m, err ?: "imeshindwa")
                        delay(1_500)   // usitume kwa kasi mno (mitandao ya simu huzuia)
                    }
                    delay(if (list.isEmpty()) 8_000 else 1_000)
                } catch (e: Exception) {
                    Log.w("Gateway", "loop error: ${e.message}")
                    update("Hitilafu ya muda - inajaribu tena...")
                    delay(backoff); backoff = (backoff * 2).coerceAtMost(120_000)
                }
            }
        }
    }

    /** Inatuma SMS na kusubiri jibu la mtandao wa simu (RESULT_OK) kwa kila kipande cha ujumbe. */
    private fun sendAndWait(to: String, text: String): Pair<Boolean, String?> {
        val sm: SmsManager = if (Build.VERSION.SDK_INT >= 31) getSystemService(SmsManager::class.java) else @Suppress("DEPRECATION") SmsManager.getDefault()
        val parts = sm.divideMessage(text)
        val action = "com.umkitendaguro.smsgateway.SENT_" + System.nanoTime()
        val latch = CountDownLatch(parts.size)
        val errorRef = java.util.concurrent.atomic.AtomicReference<String?>(null)
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                if (resultCode != Activity.RESULT_OK) errorRef.set("SMS error code=$resultCode")
                latch.countDown()
            }
        }
        ContextCompat.registerReceiver(this, receiver, IntentFilter(action), ContextCompat.RECEIVER_NOT_EXPORTED)
        return try {
            val intents = ArrayList<PendingIntent>()
            for (i in parts.indices) intents.add(PendingIntent.getBroadcast(this, i, Intent(action).setPackage(packageName), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
            sm.sendMultipartTextMessage(to, null, parts, intents, null)
            if (!latch.await(40, TimeUnit.SECONDS)) Pair(false, "timeout: hakuna jibu la mtandao wa simu") else Pair(errorRef.get() == null, errorRef.get())
        } catch (e: Exception) { Pair(false, e.message) } finally { try { unregisterReceiver(receiver) } catch (_: Exception) {} }
    }

    private fun online(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
    private fun notification(text: String): Notification {
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("gateway", "SMS Gateway", NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(this, "gateway").setContentTitle("UM SMS Gateway").setContentText(text)
            .setSmallIcon(android.R.drawable.ic_dialog_email).setOngoing(true).build()
    }
    private fun update(text: String) { getSystemService(NotificationManager::class.java).notify(1, notification(text)) }
    override fun onDestroy() { scope.cancel(); wake?.release(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
